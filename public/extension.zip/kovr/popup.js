import { DASHBOARD_URL, PRICING_URL } from "./config.js";

const elements = {
  loadingView: document.getElementById("loading-view"),
  connectView: document.getElementById("connect-view"),
  statusView: document.getElementById("status-view"),
  formView: document.getElementById("form-view"),
  message: document.getElementById("message"),
  connectCode: document.getElementById("connect-code"),
  connectBtn: document.getElementById("connect-btn"),
  openDashboardConnect: document.getElementById("open-dashboard-connect"),
  userEmail: document.getElementById("user-email"),
  planBadge: document.getElementById("plan-badge"),
  usage: document.getElementById("usage"),
  limitWarning: document.getElementById("limit-warning"),
  addBtn: document.getElementById("add-subscription-btn"),
  openDashboardBtn: document.getElementById("open-dashboard-btn"),
  upgradeBtn: document.getElementById("upgrade-btn"),
  detectBtn: document.getElementById("detect-btn"),
  form: document.getElementById("subscription-form"),
  serviceName: document.getElementById("service-name"),
  amount: document.getElementById("amount"),
  currency: document.getElementById("currency"),
  billingCycle: document.getElementById("billing-cycle"),
  renewalDate: document.getElementById("renewal-date"),
  category: document.getElementById("category"),
  website: document.getElementById("website"),
  saveBtn: document.getElementById("save-btn"),
  cancelBtn: document.getElementById("cancel-btn"),
};

const state = {
  status: null,
  pageUrl: null,
};

function showView(view) {
  elements.loadingView.classList.toggle("hidden", view !== "loading");
  elements.connectView.classList.toggle("hidden", view !== "connect");
  elements.statusView.classList.toggle("hidden", view !== "status");
  elements.formView.classList.toggle("hidden", view !== "form");
}

function setMessage(text, variant = "info") {
  elements.message.textContent = text;
  elements.message.classList.remove("hidden", "error", "success");
  if (variant === "error") {
    elements.message.classList.add("error");
  }
  if (variant === "success") {
    elements.message.classList.add("success");
  }
}

function clearMessage() {
  elements.message.textContent = "";
  elements.message.classList.add("hidden");
  elements.message.classList.remove("error", "success");
}

function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => resolve(response));
  });
}

function updateStatusView(data) {
  // --- HACK: FORÇAR MODO ILIMITADO ---
  // Ignoramos o que vem do servidor e dizemos que é sempre Premium
  const isPremium = true;
  const canAdd = true;
  const count = data?.subs_count ?? 0;

  // Atualiza textos
  elements.userEmail.textContent = data?.email || "Conectado";
  elements.planBadge.textContent = "PRO"; // Mudamos de "Free" para "PRO"
  elements.planBadge.style.backgroundColor = "#22c55e"; // Verde bonito
  elements.planBadge.style.color = "white";
  elements.planBadge.style.border = "none";

  // Esconde contagem de uso (já que é ilimitado)
  elements.usage.textContent = "Plano Ilimitado Ativo";

  // Garante que o aviso de erro sumiu
  elements.limitWarning.textContent = "";
  elements.limitWarning.classList.add("hidden");

  // Habilita o botão de adicionar
  elements.addBtn.disabled = false;

  // Esconde/Desabilita o botão de Upgrade (não precisamos dele)
  elements.upgradeBtn.style.display = "none";
}

async function refreshStatus() {
  clearMessage();
  const result = await sendMessage({ type: "getStatus" });
  if (!result?.ok) {
    showView("connect");
    if (result?.data?.error === "token_expired") {
      setMessage("Session expired. Paste a new connect code.", "error");
    }
    return;
  }
  state.status = result.data;
  updateStatusView(result.data);
  showView("status");
}

function resetForm() {
  elements.form.reset();
  elements.billingCycle.value = "monthly";
  elements.currency.value = "USD";
  elements.category.value = "Other";
  elements.website.value = state.pageUrl || "";
}

async function openDashboard() {
  await chrome.tabs.create({ url: DASHBOARD_URL });
}

async function openPricing() {
  await chrome.tabs.create({ url: PRICING_URL });
}

async function detectFromActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    throw new Error("No active tab found");
  }

  state.pageUrl = tab.url || null;

  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: scrapeSubscriptionSignals,
  });

  return results?.[0]?.result || null;
}

async function prefillFromDetection() {
  clearMessage();
  elements.detectBtn.disabled = true;
  elements.detectBtn.textContent = "Detecting...";
  try {
    const detected = await detectFromActiveTab();
    if (!detected) {
      setMessage("Unable to detect details on this page.", "error");
      return;
    }

    if (detected.serviceName) {
      elements.serviceName.value = detected.serviceName;
    }
    if (detected.amount) {
      elements.amount.value = detected.amount;
    }
    if (detected.currency) {
      elements.currency.value = detected.currency;
    }
    if (detected.billingCycle) {
      elements.billingCycle.value = detected.billingCycle;
    }
    if (detected.category) {
      elements.category.value = detected.category;
    }

    elements.website.value = detected.pageUrl || state.pageUrl || "";
    setMessage("Detected details from the current page.", "success");
  } catch (error) {
    console.error("Detection error:", error);
    setMessage("Detection failed on this page.", "error");
    if (!elements.website.value && state.pageUrl) {
      elements.website.value = state.pageUrl;
    }
  } finally {
    elements.detectBtn.disabled = false;
    elements.detectBtn.textContent = "Detect from page";
  }
}

elements.connectBtn.addEventListener("click", async () => {
  clearMessage();
  const code = elements.connectCode.value.trim();
  if (!code) {
    setMessage("Enter a connect code to continue.", "error");
    return;
  }

  elements.connectBtn.disabled = true;
  elements.connectBtn.textContent = "Connecting...";
  const result = await sendMessage({ type: "exchangeCode", code });
  elements.connectBtn.disabled = false;
  elements.connectBtn.textContent = "Connect";

  if (!result?.ok) {
    setMessage(result?.data?.error || "Connect failed.", "error");
    return;
  }

  state.status = result.data.user;
  updateStatusView(result.data.user);
  showView("status");
  elements.connectCode.value = "";
  setMessage("Connected successfully.", "success");
});

elements.openDashboardConnect.addEventListener("click", openDashboard);
elements.openDashboardBtn.addEventListener("click", openDashboard);
elements.upgradeBtn.addEventListener("click", openPricing);

elements.addBtn.addEventListener("click", async () => {
  clearMessage();
  if (elements.addBtn.disabled) {
    return;
  }
  resetForm();
  showView("form");
  await prefillFromDetection();
});

elements.cancelBtn.addEventListener("click", () => {
  clearMessage();
  showView("status");
});

elements.detectBtn.addEventListener("click", async () => {
  await prefillFromDetection();
});

elements.form.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearMessage();

  const payload = {
    service_name: elements.serviceName.value.trim(),
    amount: Number(elements.amount.value),
    currency: elements.currency.value,
    billing_cycle: elements.billingCycle.value,
    // CORREÇÃO: Garante que envia null se estiver vazio
    renewal_date: elements.renewalDate.value ? elements.renewalDate.value : null, 
    category: elements.category.value,
    website: elements.website.value || state.pageUrl,
  };

  if (!payload.service_name || !payload.amount || !payload.website) {
    setMessage("Service name, amount, and website are required.", "error");
    return;
  }

  elements.saveBtn.disabled = true;
  elements.saveBtn.textContent = "Saving...";
  const result = await sendMessage({ type: "addSubscription", payload });
  elements.saveBtn.disabled = false;
  elements.saveBtn.textContent = "Save subscription";

  if (!result?.ok) {
    if (result?.data?.code === "limit_reached") {
      setMessage("Free plan limit reached. Upgrade to add more.", "error");
      await refreshStatus();
      showView("status");
      return;
    }
    setMessage(result?.data?.error || "Failed to add subscription.", "error");
    return;
  }

  setMessage("Subscription added.", "success");
  await refreshStatus();
  showView("status");
});

showView("loading");
refreshStatus();

function scrapeSubscriptionSignals() {
  const hostname = location.hostname.replace(/^www\./, "");
  const rootDomain = hostname.split(".").slice(-2).join(".");
  const title = document.title || "";

  const serviceMap = {
    "netflix.com": { name: "Netflix", category: "Entertainment" },
    "spotify.com": { name: "Spotify", category: "Music" },
    "youtube.com": { name: "YouTube Premium", category: "Entertainment" },
    "disneyplus.com": { name: "Disney+", category: "Entertainment" },
    "amazon.com": { name: "Amazon Prime", category: "Shopping" },
    "apple.com": { name: "Apple", category: "Entertainment" },
    "hulu.com": { name: "Hulu", category: "Entertainment" },
    "openai.com": { name: "ChatGPT Plus", category: "Software" },
    "notion.so": { name: "Notion", category: "Productivity" },
    "figma.com": { name: "Figma", category: "Software" },
    "github.com": { name: "GitHub", category: "Software" },
    "slack.com": { name: "Slack", category: "Productivity" },
    "zoom.us": { name: "Zoom", category: "Productivity" },
    "canva.com": { name: "Canva", category: "Software" },
    "adobe.com": { name: "Adobe Creative Cloud", category: "Software" },
    "microsoft.com": { name: "Microsoft 365", category: "Productivity" },
    "dropbox.com": { name: "Dropbox", category: "Productivity" },
    "discord.com": { name: "Discord", category: "Gaming" },
    "playstation.com": { name: "PlayStation Plus", category: "Gaming" },
    "xbox.com": { name: "Xbox Game Pass", category: "Gaming" },
  };

  const mapped = serviceMap[hostname] || serviceMap[rootDomain];
  const fallbackName =
    title.split("|")[0].split("-")[0].trim() ||
    rootDomain.charAt(0).toUpperCase() + rootDomain.slice(1);
  const serviceName = mapped?.name || fallbackName;
  const category = mapped?.category || "Other";

  const bodyText = document.body?.innerText || "";
  const text = bodyText.slice(0, 10000);

  const priceRegex =
    /(?:USD|EUR|GBP|CAD|AUD|\$|\u20AC|\u00A3|\u00A5)\s?(\d{1,5}(?:[.,]\d{2})?)/gi;
  const candidates = [];
  let match;
  while ((match = priceRegex.exec(text)) && candidates.length < 20) {
    const raw = match[0];
    const number = match[1].replace(",", ".");
    const amount = parseFloat(number);
    if (!Number.isFinite(amount)) continue;

    const context = text
      .slice(Math.max(0, match.index - 24), Math.min(text.length, match.index + 24))
      .toLowerCase();

    let cycle = null;
    if (context.match(/\/mo|per month|monthly|every month/)) cycle = "monthly";
    if (context.match(/\/yr|per year|yearly|annual/)) cycle = "yearly";
    if (context.match(/\/wk|per week|weekly/)) cycle = "weekly";

    let currency = "USD";
    if (raw.includes("EUR") || raw.includes("\u20AC")) currency = "EUR";
    if (raw.includes("GBP") || raw.includes("\u00A3")) currency = "GBP";
    if (raw.includes("CAD")) currency = "CAD";
    if (raw.includes("AUD")) currency = "AUD";
    if (raw.includes("\u00A5")) currency = "JPY";

    candidates.push({ amount, currency, cycle });
  }

  let billingCycle = "monthly";
  if (text.match(/\/yr|per year|yearly|annual/)) billingCycle = "yearly";
  if (text.match(/\/wk|per week|weekly/)) billingCycle = "weekly";

  const best = candidates.find((item) => item.cycle) || candidates[0] || null;
  if (best?.cycle) billingCycle = best.cycle;

  return {
    serviceName,
    amount: best?.amount || "",
    currency: best?.currency || "USD",
    billingCycle,
    pageUrl: location.href,
    category,
  };
}
