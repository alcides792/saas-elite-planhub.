import { API_BASE_URL } from "./config.js";

const TOKEN_KEY = "payping_extension_token";

function getStoredToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get([TOKEN_KEY], (result) => {
      resolve(result[TOKEN_KEY] || null);
    });
  });
}

function setStoredToken(token) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [TOKEN_KEY]: token }, () => resolve());
  });
}

// MUDANÇA 1: Função de limpar token agora avisa no console em vez de apagar silenciosamente
function clearStoredToken() {
  return new Promise((resolve) => {
    console.warn("⚠️ A extensão pediu para deslogar, mas bloqueamos para DEBUG.");
    // chrome.storage.local.remove([TOKEN_KEY], () => resolve()); // LINHA COMENTADA PARA EVITAR DESCONEXÃO
    resolve();
  });
}

// MUDANÇA 2: Tratamento de erro robusto (lê texto se não for JSON)
async function apiRequest(path, { method = "GET", body } = {}, token) {
  const headers = { "Content-Type": "application/json" };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  console.log(`📡 [REQ] ${method} ${path}`);
  
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    const text = await response.text();
    console.log(`📥 [RES] Status: ${response.status}`, text);

    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      // Se der erro 500 do Next.js, ele retorna HTML, e o JSON.parse falha.
      // Aqui capturamos esse erro para mostrar no console.
      console.error("❌ Erro ao ler JSON (provável erro 500):", text.slice(0, 100));
      data = { error: `Server Error (${response.status})` };
    }

    return { ok: response.ok, status: response.status, data };
  } catch (error) {
    console.error("❌ Erro de Rede:", error);
    return { ok: false, status: 0, data: { error: "Network Error" } };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  // ... dentro do listener onMessage ...

  if (message?.type === "exchangeCode") {
    (async () => {
      console.log("🔄 Trocando código:", message.code);
      const result = await apiRequest(
        "/api/extension/connect/exchange",
        { method: "POST", body: { code: message.code } },
        null
      );

      // --- A CORREÇÃO ESTÁ AQUI ---
      // O token vem dentro de result.data.data.extension_token
      // Adicionei logs para você ver o que está chegando
      console.log("📦 JSON Recebido:", result.data);

      const token = result.data?.data?.extension_token || result.data?.extension_token;

      if (result.ok && token) {
        console.log("✅ Token encontrado:", token);
        await setStoredToken(token);
        console.log("💾 Token salvo no storage!");
        
        // Verificação dupla para garantir
        const check = await getStoredToken();
        console.log("🔍 Verificação pós-salvamento:", check);
      } else {
        console.error("❌ Token não encontrado no JSON:", result.data);
      }

      sendResponse(result);
    })();
    return true;
  }

// ... resto do código ...

  if (message?.type === "getStatus") {
    (async () => {
      const token = await getStoredToken();
      if (!token) {
        console.log("🚫 Sem token no storage.");
        sendResponse({ ok: false, status: 401, data: { error: "not_connected" } });
        return;
      }

      const result = await apiRequest("/api/extension/me", {}, token);
      
      // REMOVIDO: A lógica que chamava clearStoredToken() se desse 401
      if (!result.ok) {
        console.warn("❌ Falha no /me:", result.data);
      }

      sendResponse(result);
    })();
    return true;
  }

  if (message?.type === "addSubscription") {
    (async () => {
      const token = await getStoredToken();
      if (!token) {
        sendResponse({ ok: false, status: 401, data: { error: "not_connected" } });
        return;
      }

      console.log("💾 Enviando assinatura...", message.payload);
      const result = await apiRequest(
        "/api/extension/subscriptions",
        { method: "POST", body: message.payload },
        token
      );

      sendResponse(result);
    })();
    return true;
  }

  if (message?.type === "clearAuth") {
    (async () => {
      await chrome.storage.local.remove([TOKEN_KEY]); // Aqui permitimos apagar se o usuário clicar em Logout explicitamente
      sendResponse({ ok: true });
    })();
    return true;
  }

  return false;
});