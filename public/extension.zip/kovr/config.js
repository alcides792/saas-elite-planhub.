export const API_BASE_URL = "http://localhost:3000";
export const DASHBOARD_URL = "http://localhost:3000/dashboard";
export const PRICING_URL = "http://localhost:3000/pricing";
